import 'dart:convert';
import 'dart:io';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:image_picker/image_picker.dart';


/// Handles the optional profile photo: pick -> upload to Storage -> save URL
/// in Firestore at users/{uid}.photoUrl.
class ProfileService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  final FirebaseStorage _storage = FirebaseStorage.instance;
  final ImagePicker _picker = ImagePicker();

  String get _uid => FirebaseAuth.instance.currentUser!.uid;

  DocumentReference<Map<String, dynamic>> get _userRef =>
      _db.collection('users').doc(_uid);

  /// Live user profile (firstName, lastName, email, photoUrl).
  Stream<DocumentSnapshot<Map<String, dynamic>>> userStream() =>
      _userRef.snapshots();

  /// Opens the camera or the gallery. Returns null if the user cancels.
  Future<File?> pickImage(ImageSource source) async {
    final picked = await _picker.pickImage(
      source: source,
      maxWidth: 800,
      maxHeight: 800,
      imageQuality: 80,
    );
    return picked == null ? null : File(picked.path);
  }

  /// Uploads to profile_photos/{uid}.jpg and saves the download URL.
  Future<String> uploadProfilePhoto(File file) async {
  final bytes = await file.readAsBytes();
  final b64 = base64Encode(bytes);
  await _userRef.set({'photoUrl': b64}, SetOptions(merge: true));
  return b64;
  }

  Future<void> removeProfilePhoto() async {
    await _userRef.set({'photoUrl': null}, SetOptions(merge: true));
  }
}
